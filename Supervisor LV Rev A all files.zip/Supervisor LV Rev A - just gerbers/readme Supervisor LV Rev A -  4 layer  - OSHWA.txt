Board name and part number= Supervisor LV Rev A - 4 layer

For company = Offgrid Systems LLC, Clinton, WA 
Quantity = 13 pcs
Ship via= UPS or Fedex

PCB = FR4, 0.063 in thickness, 94V0 rated, Tg=170C
Layers =  4 layers copper, 
Silkscreen legend = Top and Bottom 
Soldermask = Top and Bottom

SPECIAL REQUESTS = 

-- Please check Gerber files and compare with IPC-D356 netlist in gerber zip folder

Copper = 1 oz copper on all four layers, holes must be thru-hole plated 1oz copper min
	
Finish = No lead solder for ROHS compatibility, hot air leveled. 


Solder mask color = BLUE LPI 
Solder mask layers =  top and bottom layers
Silk screen = White silkscreen on top and bottom layers

Gerber Files for processing:
Supervisor LV Rev A - 4 layer.cmp (top layer copper)
Supervisor LV Rev A - 4 layer.L2 (layer 2 copper)
Supervisor LV Rev A - 4 layer.L3 (layer 3 copper)
Supervisor LV Rev A - 4 layer.sol (bottom layer copper)

Supervisor LV Rev A - 4 layer.plc (top silkscreen layer)
Supervisor LV Rev A - 4 layer.pls (bottom silkscreen layer)

Supervisor LV Rev A - 4 layer.stc (top soldermask)
Supervisor LV Rev A - 4 layer.sts (bottom soldermask)

Supervisor LV Rev A - 4 layer.crc (top solder paste)
Supervisor LV Rev A - 4 layer.crs (bottom solder paste)



Excellon Drill filles:
Supervisor LV Rev A - 4 layer.dri (holes sizes and number)
Supervisor LV Rev A - 4 layer.drd (hole locations)

IPC netlist file:
Supervisor LV Rev A - 4 layer.ipc

CAD pick and place file:
Supervisor LV Rev A - 4 layer.CAD	



Bare board electrical testing = YES, Required

Tim at 360-630-1962 (USA)
Copyright 2015 Offgrid Systems LLC